package com.example.nonton_yuk

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
